"""Controller layer: Flask routes. Models live in models.py, views in templates/."""
import os
import uuid
from datetime import datetime

from flask import Flask, flash, jsonify, redirect, render_template, request, session, url_for

import models

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me")

# In-memory order store (swap for a database in production).
ORDERS = {}


def get_cart():
    return session.setdefault("cart", {})


@app.context_processor
def inject_cart_count():
    return {"cart_count": sum(session.get("cart", {}).values())}


@app.route("/")
def index():
    selected = request.args.get("category", "All")
    items = models.MENU if selected == "All" else [i for i in models.MENU if i["category"] == selected]
    return render_template("index.html", items=items, categories=models.categories(), selected=selected)


@app.route("/cart/add/<int:item_id>", methods=["POST"])
def add_to_cart(item_id):
    item = models.get_item(item_id)
    if not item:
        return jsonify(error="Item not found"), 404
    cart = get_cart()
    cart[str(item_id)] = cart.get(str(item_id), 0) + 1
    session.modified = True
    count = sum(cart.values())
    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify(ok=True, count=count, name=item["name"])
    flash(f"{item['name']} added to cart.")
    return redirect(request.referrer or url_for("index"))


@app.route("/cart")
def cart():
    return render_template("cart.html", cart=models.build_cart(get_cart()))


@app.route("/cart/update/<int:item_id>", methods=["POST"])
def update_cart(item_id):
    cart = get_cart()
    action = request.form.get("action")
    key = str(item_id)
    if key in cart:
        if action == "inc":
            cart[key] += 1
        elif action == "dec":
            cart[key] -= 1
        elif action == "remove":
            cart[key] = 0
        if cart[key] < 1:
            del cart[key]
        session.modified = True
    return redirect(url_for("cart"))


@app.route("/checkout", methods=["GET", "POST"])
def checkout():
    summary = models.build_cart(get_cart())
    if not summary["lines"]:
        flash("Your cart is empty.")
        return redirect(url_for("index"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        address = request.form.get("address", "").strip()
        errors = []
        if len(name) < 2:
            errors.append("Please enter your name.")
        if not (phone.isdigit() and len(phone) == 10):
            errors.append("Phone must be a 10-digit number.")
        if len(address) < 8:
            errors.append("Please enter a complete delivery address.")
        if errors:
            for e in errors:
                flash(e)
            return render_template("checkout.html", cart=summary, form=request.form), 400

        order_id = uuid.uuid4().hex[:8].upper()
        ORDERS[order_id] = {
            "id": order_id,
            "customer": {"name": name, "phone": phone, "address": address},
            "cart": summary,
            "placed_at": datetime.now().strftime("%d %b %Y, %I:%M %p"),
        }
        session["cart"] = {}
        return redirect(url_for("confirmation", order_id=order_id))

    return render_template("checkout.html", cart=summary, form={})


@app.route("/order/<order_id>")
def confirmation(order_id):
    order = ORDERS.get(order_id)
    if not order:
        flash("Order not found.")
        return redirect(url_for("index"))
    return render_template("confirmation.html", order=order)


if __name__ == "__main__":
    app.run(debug=True)
