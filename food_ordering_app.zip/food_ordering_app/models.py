"""Model layer: menu data and cart/order calculations (no Flask imports)."""

MENU = [
    {"id": 1, "name": "Margherita Pizza", "category": "Pizza", "price": 249,
     "description": "Classic tomato, mozzarella and fresh basil.", "emoji": "🍕"},
    {"id": 2, "name": "Paneer Tikka Pizza", "category": "Pizza", "price": 299,
     "description": "Smoky paneer, onions and capsicum on a thin crust.", "emoji": "🍕"},
    {"id": 3, "name": "Veg Burger", "category": "Burgers", "price": 149,
     "description": "Crispy veggie patty with lettuce and house sauce.", "emoji": "🍔"},
    {"id": 4, "name": "Chicken Burger", "category": "Burgers", "price": 189,
     "description": "Juicy grilled chicken with cheese and mayo.", "emoji": "🍔"},
    {"id": 5, "name": "Hyderabadi Biryani", "category": "Mains", "price": 279,
     "description": "Fragrant basmati rice slow-cooked with spices.", "emoji": "🍛"},
    {"id": 6, "name": "Butter Chicken Bowl", "category": "Mains", "price": 259,
     "description": "Creamy tomato gravy served with jeera rice.", "emoji": "🍲"},
    {"id": 7, "name": "Masala Dosa", "category": "South Indian", "price": 99,
     "description": "Crisp dosa filled with spiced potato, with chutneys.", "emoji": "🥞"},
    {"id": 8, "name": "French Fries", "category": "Sides", "price": 89,
     "description": "Golden and salted, served hot.", "emoji": "🍟"},
    {"id": 9, "name": "Chocolate Brownie", "category": "Desserts", "price": 119,
     "description": "Warm fudgy brownie with chocolate drizzle.", "emoji": "🍫"},
    {"id": 10, "name": "Cold Coffee", "category": "Drinks", "price": 109,
     "description": "Chilled blended coffee with ice cream.", "emoji": "🥤"},
]

TAX_RATE = 0.05
DELIVERY_FEE = 30
FREE_DELIVERY_ABOVE = 500


def get_item(item_id):
    return next((i for i in MENU if i["id"] == item_id), None)


def categories():
    seen = []
    for item in MENU:
        if item["category"] not in seen:
            seen.append(item["category"])
    return seen


def build_cart(raw_cart):
    """Turn {item_id: qty} from the session into line items and totals."""
    lines = []
    subtotal = 0
    for key, qty in raw_cart.items():
        item = get_item(int(key))
        if not item or qty < 1:
            continue
        line_total = item["price"] * qty
        subtotal += line_total
        lines.append({**item, "qty": qty, "line_total": line_total})
    tax = round(subtotal * TAX_RATE, 2)
    delivery = 0 if (subtotal == 0 or subtotal >= FREE_DELIVERY_ABOVE) else DELIVERY_FEE
    return {
        "lines": lines,
        "subtotal": subtotal,
        "tax": tax,
        "delivery": delivery,
        "total": round(subtotal + tax + delivery, 2),
        "count": sum(l["qty"] for l in lines),
    }
