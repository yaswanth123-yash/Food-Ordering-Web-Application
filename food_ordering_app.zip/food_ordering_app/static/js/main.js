// Progressive enhancement: add to cart without a page reload.
// Without JavaScript the forms still work as normal POST requests.
(function () {
  const badge = document.getElementById("cart-count");
  const toast = document.getElementById("toast");
  let timer;

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(timer);
    timer = setTimeout(() => toast.classList.remove("show"), 1800);
  }

  document.querySelectorAll(".add-form").forEach((form) => {
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      try {
        const res = await fetch(form.action, {
          method: "POST",
          headers: { "X-Requested-With": "fetch" },
        });
        if (!res.ok) throw new Error("Request failed");
        const data = await res.json();
        badge.textContent = data.count;
        showToast(data.name + " added to cart");
      } catch (err) {
        form.submit(); // fall back to a normal submit
      }
    });
  });
})();
