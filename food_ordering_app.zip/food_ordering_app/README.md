# Tasty Bites: Food Ordering Web Application

A responsive food ordering site built with semantic HTML5, CSS3 and Flask.

## Structure (MVC)

```
food_ordering_app/
├── app.py            # Controller: routes and request handling
├── models.py         # Model: menu data, cart and price calculations
├── templates/        # View: Jinja2 templates (base layout + pages)
│   ├── base.html
│   ├── index.html
│   ├── cart.html
│   ├── checkout.html
│   └── confirmation.html
├── static/
│   ├── css/style.css # Responsive styles
│   └── js/main.js    # Add-to-cart without page reload
└── requirements.txt
```

## Run it

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Features

- Menu with category filters
- Session-based cart (add, increase, decrease, remove)
- Tax, delivery fee and free delivery above ₹500
- Checkout with server-side validation
- Order confirmation page

## Notes

Orders are stored in memory, so they reset when the server restarts. Swap the `ORDERS` dict in `app.py` for a database (e.g. SQLite with Flask-SQLAlchemy) for persistence. Set the `SECRET_KEY` environment variable in production.
